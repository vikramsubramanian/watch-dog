# Hello Crimes Back End

This is a hello world type application to display the crime data from the DB.

## Running Locally

Note: You will need to create a .env file with the database parameters.

### API Endpoints available:

- List of robberies
  - `/robberies/`
- Get robbery by event ID
  - `/robberies/eventId`
