CREATE INDEX YearMonth ON IncidentTime(year, month);

CREATE INDEX InvolvedPersonAge ON InvolvedPerson(age);