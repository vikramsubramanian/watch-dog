CREATE INDEX YearMonth ON IncidentTime(year, month);

CREATE INDEX InvolvedPersonAge ON InvolvedPerson(age);

-- New Indexes

CREATE INDEX MCI ON RegularCrime(MCI);

CREATE INDEX BikeType ON BikeTheft(bike_type);

CREATE INDEX InvolvedPersonType ON InvolvedPerson(involvement_type);