# Data CSV Files

The production data files are WIP, and appended with '\_prod'. The raw files are appended with '\_raw'. The other files hold the sample database data.
